<?php 

include '../../config.php';

$admin = new Admin();

if (!isset($_SESSION['admin_id'])) {
    header("location:login_front.php");
}
$s_variable = $_SESSION['admin_id']; 

//---create/insert location
if(isset($_POST['add_officer'])){ 

	$o_name = $_POST['o_name']; 

    $username = $_POST['username']; 

    $password = $_POST['password']; 

    $email = $_POST['email']; 

//image
$imagetargetfolder ='../uploads/'; //folder in which we store image
$imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] is name in HTML input tag
move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 

$query=$admin->cud("INSERT INTO `officer`(`o_name`,`username`,`password`,`email`,`officer_photo`) 
VALUES('$o_name','$username','$password','$email','$imagename')","saved");

echo "<script>alert('inserted successfully');window.location.href='../officer_manage.php';</script>";
}          
?>

<?php
//update------------------------------------------------------------------
if(isset($_POST['update_officer'])){ 

    $oid = $_POST['oid']; //hidden id passed in update form

	$o_name = $_POST['o_name']; 

    $username =$_POST['username'];  

    $password =$_POST['password']; 

    $email =$_POST['email']; 

    $imagename =$_POST['img']; //old image

    //new image
    if(is_uploaded_file($_FILES["image"]["tmp_name"])){
        $imagetargetfolder ='../uploads/'; 
        $imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] HTML tag input imagedb name
        move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 
    }

$query=$admin->cud("UPDATE `officer` SET `o_name`='$o_name', `username`='$username', `password`='$password' ,`email`='$email' ,`officer_photo`='$imagename' where officer.oid='$oid' ","updated successfully"); 

echo "<script>alert('updated');window.location.href='../officer_manage.php';</script>";
}
?>

<?php
//delete------------------------------------------------------------------
if(isset($_GET['delete_officer'])){  //delete_locations id is href variable from locations_manage delete button

$oid =$_GET['delete_officer']; 

$query=$admin->cud("DELETE FROM `officer` where `oid`='$oid'  ","Deleted successfully");

echo "<script>alert('deleted'); window.location.href='../officer_manage.php';</script>";
}

?>