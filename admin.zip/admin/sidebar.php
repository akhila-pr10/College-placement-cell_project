<nav class="sidebar sidebar-offcanvas" id="sidebar">
  <ul class="nav">

    <li class="nav-item">
      <a class="nav-link" href="admin_index.php">
        <span class="menu-title">Dashboard</span>
        <i class="mdi mdi-home menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="officer_manage.php">
        <span class="menu-title">Manage officer</span>
        <i class="mdi mdi-table-large menu-icon"></i>
      </a>
    </li>


    <li class="nav-item">
      <a class="nav-link" href="student_manage.php">
        <span class="menu-title">View students</span>
        <i class="mdi mdi-table-large menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="view_feedback.php">
        <span class="menu-title">Student Feedbacks</span>
        <i class="mdi mdi-contacts menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="view_offerletters.php">
        <span class="menu-title">Offer letters</span>
        <i class="mdi mdi-contacts menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="placed.php">
        <span class="menu-title">placed students</span>
        <i class="mdi mdi-chart-bar menu-icon"></i>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link" href="view_report.php">
        <span class="menu-title">Reports</span>
        <i class="mdi mdi-chart-bar menu-icon"></i>
      </a>
    </li>


  </ul>
</nav>