<!doctype html>
<html lang="en">
  <head>
  	<title>Student Registration</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link href="https://fonts.googleapis.com/css?family=Lato:300,400,700&display=swap" rel="stylesheet">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
	
	<link rel="stylesheet" href="assets/login_page_assets/css/style.css">

	</head>
	<body>
	<section class="ftco-section">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-md-6 text-center mb-5">
					<h2 class="heading-section">Student Registration</h2>
				</div>
			</div>
			<div class="row justify-content-center">
				<div class="col-md-7 col-lg-5">
					<div class="login-wrap p-4 p-md-5">
		      	<div class="icon d-flex align-items-center justify-content-center">
		      		<span class="fa fa-user-o"></span>
		      	</div>
		      	<h3 class="text-center mb-4">Student Registration</h3>
					
                        <form action="controller/login_controller.php" method="POST" autocomplete="off" enctype="multipart/form-data" class="login-form">

                        <div class="form-group">
		      			<input type="text" class="form-control rounded-left" name="name"  placeholder="name" required pattern="[a-zA-Z'-'\s]*" title="No numbers or special are allowed">
		      		</div>

		      		<div class="form-group">
		      			<input type="text" class="form-control rounded-left" name="username"  placeholder="Username" required pattern="[a-z]+" title="only lower case letters are allowed without space">
		      		</div>

	            <div class="form-group d-flex">
	              <input type="password" class="form-control rounded-left"  name="password" placeholder="Password" required pattern="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*_=+-]).{8,12}$" title="At least 1 Uppercase, 1 Lowercase, 1 Number,1 Symbol(!@#$%^&*_=+-) Min 8 chars and Max 12 chars">
	            </div>

                <div class="form-group d-flex">
	              <input type="email" class="form-control rounded-left"  name="email" placeholder="email" required>
	            </div>

                <div class="form-group d-flex">
	              <input type="text" class="form-control rounded-left"  name="phoneno"  placeholder="Phone number" required pattern="[7-9]{1}[0-9]{9}" title="Phone number should start with 7,8,9 and contain 10 digits">
	            </div>

                <div class="form-group d-flex">
	              <input type="text" class="form-control rounded-left"  name="sslc" placeholder="sslc marks percentage" required>
	            </div>

                <div class="form-group d-flex">
	              <input type="text" class="form-control rounded-left"  name="puc" placeholder="PUC marks percentage" required>
	            </div>

                <div class="form-group d-flex">
	              <input type="text" class="form-control rounded-left"  name="degree" placeholder="degree marks percentage" required>
	            </div>

				<label>Date of Birth</label> <br>
                <div class="form-group d-flex">
	              <input type="date" class="form-control rounded-left"  name="dob" placeholder="dob" required>
	            </div>
                <div class="form-group d-flex">
	              <input type="text" class="form-control rounded-left"  name="aadhar_no" placeholder="Aadhar number" required pattern="[0-9]{12}" title="Aadhar number is 12 digits">
	            </div>

				<div class="form-group d-flex">
	              <!-- <input type="text" class="form-control rounded-left"  name="aadhar_no" placeholder="Aadhar number" required> -->
				  <select name="course"  class="form-control" required>
					<option selected disabled value="">select course</option>
					<option value="BCA">BCA</option>
					<option value="Bsc">BSc</option>
				  </select>
	            </div>

                <div class="form-group d-flex">
	              <input type="file" class="form-control rounded-left"  name="image" placeholder="photo" required>
	            </div>
	            <div class="form-group">
	            	<input type="submit" value=" Register" name="register"class="form-control btn btn-primary rounded submit px-3">
	            </div>

				


	            <div class="form-group d-md-flex">

								<div class="w-100 text-md-right">
									<a href="login_front.php">Already have an account? Login</a>
								</div>
	            </div>
	          </form>
	        </div>
				</div>
			</div>
		</div>
	</section>

	<script src="assets/login_page_assets/js/jquery.min.js"></script>
  <script src="assets/login_page_assets/js/popper.js"></script>
  <script src="assets/login_page_assets/js/bootstrap.min.js"></script>
  <script src="assets/login_page_assets/js/main.js"></script>


	</body>
</html>

