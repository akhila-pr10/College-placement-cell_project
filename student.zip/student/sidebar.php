<nav class="sidebar sidebar-offcanvas" id="sidebar">
          <ul class="nav">
     
            <li class="nav-item">
              <a class="nav-link" href="student_index.php">
                <span class="menu-title">Dashboard</span>
                <i class="mdi mdi-home menu-icon"></i>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="applied.php">
                <span class="menu-title">applied</span>
                <i class="mdi mdi-table-large menu-icon"></i>
              </a>
            </li>


            <li class="nav-item">
              <a class="nav-link" href="attended_assesment.php">
                <span class="menu-title">attended assesment</span>
                <i class="mdi mdi-table-large menu-icon"></i>
              </a>
            </li>

            <li class="nav-item">
              <a class="nav-link" href="shortlisted.php">
                <span class="menu-title">shortlisted</span>
                <i class="mdi mdi-contacts menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="attended_interview.php">
                <span class="menu-title">attended interview</span>
                <i class="mdi mdi-format-list-bulleted menu-icon"></i>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="placed.php">
                <span class="menu-title">placed</span>
                <i class="mdi mdi-chart-bar menu-icon"></i>
              </a>
            </li>  
           

            <li class="nav-item">
              <a class="nav-link" href="offer_letter_upload.php">
                <span class="menu-title">Upload offer letter</span>
                <i class="mdi mdi-chart-bar menu-icon"></i>
              </a>
            </li> 

          </ul>
        </nav>