<?php

include '../../config.php';

$admin = new Admin();

if (!isset($_SESSION['sid'])) {
    header("location:../login_front.php");
}
$s_variable = $_SESSION['sid'];

//---create/insert location
if (isset($_GET['visit_link'])) {

    $v_idv = $_GET['visit_link'];  //vacanccy id

    $sidv = $s_variable;

    $job_link = $_GET['job_link'];

    $visit_status = 'visited';

    // checking if already exist
    $query1 = $admin->ret("SELECT * FROM `visit` WHERE `v_idv`='$v_idv' AND `sidv`='$sidv' ");
    $row = $query1->fetch(PDO::FETCH_ASSOC);

    if ($query1->rowCount() > 0) {
        $query = $admin->cud("UPDATE `visit` SET `visit_status`='$visit_status' where visit.v_idv='$v_idv' ", "updated successfully");
        echo "<script>alert('visit to official link');window.location.href='$job_link';</script>";
    } else {


        $query = $admin->cud("INSERT INTO `visit`(`v_idv`,`sidv`,`visit_date`,`visit_status`) 
VALUES('$v_idv','$sidv',now(),'$visit_status')", "saved");

        echo "<script>alert('visit to official link');window.location.href='$job_link';</script>";
    }
}
