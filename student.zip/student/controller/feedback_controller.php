<?php 

include '../../config.php';

$admin = new Admin();

if (!isset($_SESSION['sid'])) {
    header("location:../login_front.php");
}

$s_variable = $_SESSION['sid']; 

//---create/insert location
if(isset($_POST['send_feedback'])){ 

	$sidf = $s_variable;

    $message = $_POST['message']; 


$query1=$admin->cud("INSERT INTO `feedback`(`sidf`,`message`) VALUES('$sidf','$message')","saved");

echo "<script>alert('inserted successfully');window.location.href='../../feedback.php';</script>";
}          
?>