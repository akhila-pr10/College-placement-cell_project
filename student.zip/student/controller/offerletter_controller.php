<?php 

include '../../config.php';

$admin = new Admin();

if (!isset($_SESSION['sid'])) {
    header("location:login_front.php");
}
$s_variable = $_SESSION['sid']; 

//---create/insert location
if(isset($_POST['upload_offerletter'])){ 

	$sidol = $s_variable;


//image
$imagetargetfolder ='../uploads/'; //folder in which we store image
$imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] is name in HTML input tag
move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 

$query=$admin->cud("INSERT INTO `offer_letter`(`sidol`,`offer_letter_file`) VALUES('$sidol','$imagename')","saved");

echo "<script>alert('inserted successfully');window.location.href='../offer_letter_upload.php';</script>";
}          
?>