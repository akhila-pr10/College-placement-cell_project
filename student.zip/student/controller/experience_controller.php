<?php 

include '../../config.php';

$admin = new Admin();

if (!isset($_SESSION['sid'])) {
    header("location:login_front.php");
}

$s_variable = $_SESSION['sid']; 

//---create/insert location
if(isset($_POST['send_experience'])){ 

	$vide = $_POST['vide']; 

    $status = $_POST['status']; 

    $student_experience = $_POST['student_experience']; 

    $job_date = $_POST['job_date']; 

    $side=$s_variable;

$query1=$admin->cud("INSERT INTO `experience`(`vide`,`status`,`student_experience`,`job_date`,`side`) VALUES('$vide','$status', '$student_experience','$job_date','$side')","saved");

echo "<script>alert('inserted successfully');window.location.href='../student_index.php';</script>";
}          
?>

<?php
//update------------------------------------------------------------------
if(isset($_POST['vaccancy_update'])){ 

    $v_id = $_POST['v_id']; //hidden id passed in update form

	$c_name = $_POST['c_name']; 

    $eligibility =$_POST['eligibility'];  

    $designation =$_POST['designation']; 

    $salary =$_POST['salary']; 

    $experience =$_POST['experience']; 

    $location =$_POST['location']; 


    $imagename =$_POST['img']; //old image

    //new image
    if(is_uploaded_file($_FILES["image"]["tmp_name"])){
        $imagetargetfolder ='../uploads/'; 
        $imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] HTML tag input imagedb name
        move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 
    }

$query=$admin->cud("UPDATE `vaccancy` SET `c_name`='$c_name', `eligibility`='$eligibility',`designation`='$designation',`salary`='$salary' ,`experience`='$experience', `location`='$location' ,`company_photo`='$imagename' where vaccancy.v_id='$v_id' ","updated successfully"); 

echo "<script>alert('updated');window.location.href='../vaccancy_manage.php';</script>";
}
?>

<?php
//delete------------------------------------------------------------------
if(isset($_GET['delete_vaccancy'])){  //delete_locations id is href variable from locations_manage delete button

$v_id =$_GET['delete_vaccancy']; 

$query=$admin->cud("DELETE FROM `vaccancy` where `v_id`='$v_id'  ","Deleted successfully");

echo "<script>alert('deleted'); window.location.href='../vaccancy_manage.php';</script>";
}

?>