<?php 

include '../../config.php';

$admin = new Admin();


$s_variable = $_SESSION['sid']; 

//---create/insert location
if(isset($_POST['send_message'])){ 

	$message = $_POST['message'];  

    $sidc = $s_variable;

    $who='student_sent';


$query=$admin->cud("INSERT INTO `chat`(`sidc`,`message`,`who`,`sent_datetime`) 
VALUES('$sidc','$message', '$who',now() )","saved");


echo "<script>window.location.href='../../student_chat.php';</script>";
}          
?>