<?php

include '../../config.php';

$admin = new Admin();


if(isset($_POST['login'])){

	$username = $_POST['username'];

	$password = $_POST['password'];

	$query=$admin->ret("SELECT * FROM `student` WHERE `username`='$username' AND `password`='$password' ");


//couting row
	$num=$query->rowCount();

	if($num>0){
		$row=$query->fetch(PDO::FETCH_ASSOC);

		$id =$row['sid'];
		$_SESSION['sid']=$id; //used to uniquely identify user session. use this in user pages

		echo "<script>alert('login successful'); window.location.href='../../index.php';</script>";

	}


	else
	{
		echo "<script>alert('wrong username or password..!'); window.location.href='../../index.php';</script>";
	}
	
}

?>


<?php
//Registration
if(isset($_POST['register'])){

	$name = $_POST['name'];

	$username = $_POST['username'];

	$password = $_POST['password'];

    $phoneno = $_POST['phoneno'];
	

	$email = $_POST['email'];

	$sslc = $_POST['sslc'];

	$puc = $_POST['puc'];

	$degree = $_POST['degree'];

	$aadhar_no = $_POST['aadhar_no'];

	$dob = $_POST['dob'];

	$course = $_POST['course'];
	

	//---image
	$imagetargetfolder ='../uploads/';  // folder to store images
	$imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] is HTML name=""
	move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 
	
	$query=$admin->cud("INSERT INTO `student` (`name`,`username`,`password`,`phoneno`,`email`,`sslc`,`puc`,`degree`,`aadhar_no`,`dob`,`photo`,`course`) 
	VALUES('$name','$username','$password','$phoneno','$email','$sslc','$puc','$degree','$aadhar_no','$dob','$imagename','$course')","saved");
	
	echo "<script>alert('registration successful'); window.location.href='../../index.php';</script>";
	}
	
	
	

?>