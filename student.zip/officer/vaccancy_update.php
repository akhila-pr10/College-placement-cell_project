<?php

include '../config.php';

$admin = new Admin();

if (!isset($_SESSION['oid'])) {
    header("location:login_front.php");

}
$s_variable = $_SESSION['oid']; 
?>


<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Purple Admin</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="assets/dashboard_assets/assets/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="assets/dashboard_assets/assets/vendors/css/vendor.bundle.base.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <!-- endinject -->
    <!-- Layout styles -->
    <link rel="stylesheet" href="assets/dashboard_assets/assets/css/style.css">
    <!-- End layout styles -->
    <link rel="shortcut icon" href="assets/dashboard_assets/assets/images/favicon.ico" />
  </head>
  <body>
    <div class="container-scroller">

      <!-- partial:partials/_navbar.html -->
<!-- 🟨 header -->
<?php include 'header.php' ?>


      <!-- partial -->
      <div class="container-fluid page-body-wrapper">
        <!-- partial:partials/_sidebar.html -->
<!-- 🟨 sidebar -->
<?php include 'sidebar.php' ?>
        <!-- partial -->
        <div class="main-panel">
          <div class="content-wrapper">

<!-- 🟩 MAIN CONTENT AREA ----------------------------------------------------------------------- -->
<?php
    $v_id = $_GET['edit_vaccancy'];  //this is from update button hyperlink
    $query = $admin->ret("SELECT * FROM `vaccancy` where `v_id`= '$v_id' ");
    $row = $query->fetch(PDO::FETCH_ASSOC);
    ?>

           
<div class="col-md-6 grid-margin stretch-card">
                <div class="card">
                  <div class="card-body">
                    <h4 class="card-title">Add vaccancy</h4>
                    <!-- <p class="card-description"> Basic form layout </p> -->
    
                    <form class="forms-sample" action="controller/vaccancy_controller.php" method="POST" enctype="multipart/form-data" autocomplete="off">

                    <div class="form-group">
                        <label for="exampleInputUsername1">Company name</label>
                        <input type="text" class="form-control" value="<?php echo $row['c_name'] ?>" id="exampleInputUsername1" name="c_name" placeholder="Companyname">
                      </div>

                      <!-- sending as hidden -->
                      <input type="hidden" name="v_id" value="<?php echo $row['v_id'] ?>">

                      <div class="form-group">
                        <label for="exampleInputUsername1">Experience</label>
                        <input type="text" class="form-control" value="<?php echo $row['experience'] ?>" id="exampleInputUsername1" name="experience" placeholder="experience">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputPassword1">Designation</label>
                        <input type="text" class="form-control" value="<?php echo $row['designation'] ?>" id="exampleInputPassword1"  name="designation" placeholder="designation">
                      </div>

                      <div class="form-group">
                        <label for="exampleInputEmail1">Eligibility</label>
                        <input type="text" class="form-control" value="<?php echo $row['eligible_course'] ?>" id="exampleInputEmail1"  name="eligible_course" placeholder="eligibility">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">Salary</label>
                        <input type="text" class="form-control" value="<?php echo $row['salary'] ?>" id="exampleInputEmail1"  name="salary"placeholder="salary">
                      </div>
                      <div class="form-group">
                        <label for="exampleInputEmail1">location</label>
                        <input type="text" class="form-control" value="<?php echo $row['location'] ?>" id="exampleInputEmail1"  name="location"placeholder="location">
                      </div>


    
                      <div class="form-group">
                        <label for="exampleInputConfirmPassword1">Photo</label>
                        <input type="file" class="form-control"  id="exampleInputConfirmPassword1" name="image" placeholder="Photo">
                      </div>

                      
        <!--sending old image as hidden-->
        <input type="hidden" value="<?php echo $row['company_photo'] ?>" name="img">

                      <div class="form-check form-check-flat form-check-primary">
                        <label class="form-check-label">
                          <input type="checkbox" class="form-check-input"> Remember me </label>
                      </div>
                      <input type="submit" name="vaccancy_update" value="Submit" class="btn btn-gradient-primary me-2">
                      <button class="btn btn-light">Cancel</button>
                    </form>
                  </div>
                </div>
              </div>
            <!-- 🟩 MAIN CONTENT STARTS ----------------------------------------------------------------------- -->
          </div>p
          <!-- content-wrapper ends -->
          <!-- partial:partials/_footer.html -->

          <!-- 🟨 footer -->
          <?php include 'footer.php' ?>

          <!-- partial -->
        </div>
        <!-- main-panel ends -->
      </div>
      <!-- page-body-wrapper ends -->
    </div>
    <!-- container-scroller -->
    <!-- plugins:js -->
    <script src="assets/dashboard_assets/assets/vendors/js/vendor.bundle.base.js"></script>
    <!-- endinject -->
    <!-- Plugin js for this page -->
    <script src="assets/dashboard_assets/assets/vendors/chart.js/Chart.min.js"></script>
    <script src="assets/dashboard_assets/assets/js/jquery.cookie.js" type="text/javascript"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="assets/dashboard_assets/assets/js/off-canvas.js"></script>
    <script src="assets/dashboard_assets/assets/js/hoverable-collapse.js"></script>
    <script src="assets/dashboard_assets/assets/js/misc.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page -->
    <script src="assets/dashboard_assets/assets/js/dashboard.js"></script>
    <script src="assets/dashboard_assets/assets/js/todolist.js"></script>
    <!-- End custom js for this page -->
  </body>
</html>