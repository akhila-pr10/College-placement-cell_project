<?php 

include '../../config.php';

$admin = new Admin();


$s_variable = $_SESSION['oid']; 

//---create/insert location
if(isset($_POST['add_vaccancy'])){ 

	$c_name = $_POST['c_name']; 

    $eligible_course = $_POST['eligible_course']; 

    $designation = $_POST['designation']; 

    $salary = $_POST['salary']; 

    $experience = $_POST['experience']; 

    $location = $_POST['location']; 

    $job_link = $_POST['job_link']; 

    $min_puc = $_POST['min_puc']; 

    $min_degree = $_POST['min_degree']; 


//image
$imagetargetfolder ='../uploads/'; //folder in which we store image
$imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] is name in HTML input tag
move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 

$query=$admin->cud("INSERT INTO `vaccancy`(`c_name`,`eligible_course`,`designation`,`salary`,`experience`,`location`,`company_photo`,`job_link`,`min_puc`,`min_degree`,`update_date`) 
VALUES('$c_name','$eligible_course', '$designation','$salary','$experience','$location','$imagename','$job_link','$min_puc','$min_degree',now())","saved");

echo "<script>alert('inserted successfully');window.location.href='../vaccancy_manage.php';</script>";
}          
?>

<?php
//update------------------------------------------------------------------
if(isset($_POST['vaccancy_update'])){ 

    $v_id = $_POST['v_id']; //hidden id passed in update form

	$c_name = $_POST['c_name']; 

    $eligible_course =$_POST['eligible_course'];  

    $designation =$_POST['designation']; 

    $salary =$_POST['salary']; 

    $experience =$_POST['experience']; 

    $location =$_POST['location']; 


    $imagename =$_POST['img']; //old image

    //new image
    if(is_uploaded_file($_FILES["image"]["tmp_name"])){
        $imagetargetfolder ='../uploads/'; 
        $imagename=$imagetargetfolder.basename($_FILES["image"]["name"]); //['image'] HTML tag input imagedb name
        move_uploaded_file($_FILES["image"]["tmp_name"],$imagename); 
    }

$query=$admin->cud("UPDATE `vaccancy` SET `c_name`='$c_name', `eligible_course`='$eligible_course',`designation`='$designation',`salary`='$salary' ,`experience`='$experience', `location`='$location' ,`company_photo`='$imagename' where vaccancy.v_id='$v_id' ","updated successfully"); 

echo "<script>alert('updated');window.location.href='../vaccancy_manage.php';</script>";
}
?>

<?php
//delete------------------------------------------------------------------
if(isset($_GET['delete_vaccancy'])){  //delete_locations id is href variable from locations_manage delete button

$v_id =$_GET['delete_vaccancy']; 

$query=$admin->cud("DELETE FROM `vaccancy` where `v_id`='$v_id'  ","Deleted successfully");

echo "<script>alert('deleted'); window.location.href='../vaccancy_manage.php';</script>";
}

?>