<?php 

include '../../config.php';

$admin = new Admin();


$s_variable = $_SESSION['oid']; 

//---create/insert location
if(isset($_POST['send_message'])){ 

	$message = $_POST['message'];  

    $sidc = $_POST['sidc'];

    $who='officer_sent';


$query=$admin->cud("INSERT INTO `chat`(`sidc`,`message`,`who`,`sent_datetime`) 
VALUES('$sidc','$message', '$who',now() )","saved");


echo "<script>window.location.href='../chat_individual.php?sid=$sidc';</script>";
}          
?>