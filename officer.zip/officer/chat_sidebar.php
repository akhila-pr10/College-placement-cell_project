<div class="side-one">
    <div class="row heading">
        <div class="col-sm-6 col-xs-12 heading-avatar">
        <div class="col-sm-12 col-xs-12 heading-avatar">
        <h4 style="color:#005C4B"><b>student list</b></h4>
        </div>
        </div>
        <div class="col-sm-1 col-xs-1  heading-dot  pull-right">
            <!-- <i class="fa fa-ellipsis-v fa-2x  pull-right" aria-hidden="true"></i> -->
        </div>
        <div class="col-sm-2 col-xs-2 heading-compose  pull-right">
            <i class="fa fa-comments fa-2x  pull-right" aria-hidden="true"></i>
        </div>
    </div>



    <div class="row sideBar">

        <!-- single student starts -->
        <?php $query = $admin->ret("SELECT * FROM `student` ");
        while ($row = $query->fetch(PDO::FETCH_ASSOC)) { ?>

<a href="chat_individual.php?sid=<?php echo $row['sid'] ?>">
        <div class="row sideBar-body">
            <div class="col-sm-3 col-xs-3 sideBar-avatar">
                <div class="avatar-icon">
                <img src="../student/uploads/<?php echo $row['photo'] ?>" height="50px" width="50px">
                </div>
            </div>
            <div class="col-sm-9 col-xs-9 sideBar-main">
                <div class="row">
                    <div class="col-sm-8 col-xs-8 sideBar-name">
                       <span class="name-meta"><?php echo $row['name'] ?>
                        </span>
                    </div>
                    <div class="col-sm-4 col-xs-4 pull-right sideBar-time">
                        <span class="time-meta pull-right">student
                        </span>
                    </div>
                </div>
            </div>
        </div>
        </a>
        <?php } ?>
        <!-- single student ends -->

    </div>
</div>