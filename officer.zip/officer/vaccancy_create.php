<?php

include '../config.php';

$admin = new Admin();

if (!isset($_SESSION['oid'])) {
  header("location:login_front.php");
}
$s_variable = $_SESSION['oid'];
?>


<!DOCTYPE html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Purple Admin</title>
  <!-- plugins:css -->
  <link rel="stylesheet" href="assets/dashboard_assets/assets/vendors/mdi/css/materialdesignicons.min.css">
  <link rel="stylesheet" href="assets/dashboard_assets/assets/vendors/css/vendor.bundle.base.css">
  <!-- endinject -->
  <!-- Plugin css for this page -->
  <!-- End plugin css for this page -->
  <!-- inject:css -->
  <!-- endinject -->
  <!-- Layout styles -->
  <link rel="stylesheet" href="assets/dashboard_assets/assets/css/style.css">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="assets/dashboard_assets/assets/images/favicon.ico" />
</head>

<body>
  <div class="container-scroller">

    <!-- partial:partials/_navbar.html -->
    <!-- 🟨 header -->
    <?php include 'header.php' ?>


    <!-- partial -->
    <div class="container-fluid page-body-wrapper">
      <!-- partial:partials/_sidebar.html -->
      <!-- 🟨 sidebar -->
      <?php include 'sidebar.php' ?>
      <!-- partial -->
      <div class="main-panel">
        <div class="content-wrapper">

          <!-- 🟩 MAIN CONTENT AREA ----------------------------------------------------------------------- -->


          <div class="col-md-6 grid-margin stretch-card">
            <div class="card">
              <div class="card-body">
                <h4 class="card-title">Add vaccancy</h4>
                <!-- <p class="card-description"> Basic form layout </p> -->

                <form  action="controller/vaccancy_controller.php" method="POST" enctype="multipart/form-data" autocomplete="off">

                  <div class="form-group">
                    <label for="exampleInputUsername1">Company name</label>
                    <input type="text" class="form-control" id="exampleInputUsername1" name="c_name" placeholder="Companyname" required >
                  </div>

                  <div class="form-group">
                    <label for="exampleInputUsername1">Designation</label>
                    <input type="text" class="form-control" id="exampleInputUsername1" name="designation" placeholder="Designation" required>
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">Salary</label>
                    <input type="number" class="form-control" id="exampleInputEmail1" name="salary" placeholder="Salary" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Experience</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="experience" placeholder="Experience" required>
                  </div>
                  <div class="form-group">
                    <label for="exampleInputEmail1">Location</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="location" placeholder="Location" required>
                  </div>


                  <div class="form-group">
                    <label for="exampleInputEmail1">Course</label>
                    <select name="eligible_course" class="form-control" required>
                      <option selected disabled value="">select course</option>
                      <option value="BCA">BCA</option>
                      <option value="BSc">BSc</option>
                      <option value="Any stream">Any stream</option>
                    </select>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">Official website link</label>
                    <input type="text" class="form-control" id="exampleInputEmail1" name="job_link" placeholder="Official website link" required>
                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">PUC minimum marks</label>
                    <select name="min_puc" class="form-control" required>
                      <option selected disabled value="">select marks</option>
                      <option value="50">50</option>
                      <option value="50">60</option>
                      <option value="50">70</option>
                      <option value="50">80</option>
                      <option value="50">90</option>
                    </select>

                  </div>

                  <div class="form-group">
                    <label for="exampleInputEmail1">PUC Degree marks</label>
                    <select name="min_degree" class="form-control" required>
                      <option selected disabled value="">select marks</option>
                      <option value="50">50</option>
                      <option value="50">60</option>
                      <option value="50">70</option>
                      <option value="50">80</option>
                      <option value="50">90</option>

                  </div>
                  <br> <br>



                  <div class="form-group">
                    <label for="exampleInputConfirmPassword1">Photo</label>
                    <input type="file" class="form-control" id="exampleInputConfirmPassword1" name="image" placeholder="Photo" required>
                  </div>

  
                  <input type="submit" name="add_vaccancy" value="Submit" class="btn btn-gradient-primary me-2">
                  <button class="btn btn-light">Cancel</button>
                </form>
              </div>
            </div>
          </div>
          <!-- 🟩 MAIN CONTENT STARTS ----------------------------------------------------------------------- -->
        </div>
        <!-- content-wrapper ends -->
        <!-- partial:partials/_footer.html -->

        <!-- 🟨 footer -->
        <?php include 'footer.php' ?>

        <!-- partial -->
      </div>
      <!-- main-panel ends -->
    </div>
    <!-- page-body-wrapper ends -->
  </div>
  <!-- container-scroller -->
  <!-- plugins:js -->
  <script src="assets/dashboard_assets/assets/vendors/js/vendor.bundle.base.js"></script>
  <!-- endinject -->
  <!-- Plugin js for this page -->
  <script src="assets/dashboard_assets/assets/vendors/chart.js/Chart.min.js"></script>
  <script src="assets/dashboard_assets/assets/js/jquery.cookie.js" type="text/javascript"></script>
  <!-- End plugin js for this page -->
  <!-- inject:js -->
  <script src="assets/dashboard_assets/assets/js/off-canvas.js"></script>
  <script src="assets/dashboard_assets/assets/js/hoverable-collapse.js"></script>
  <script src="assets/dashboard_assets/assets/js/misc.js"></script>
  <!-- endinject -->
  <!-- Custom js for this page -->
  <script src="assets/dashboard_assets/assets/js/dashboard.js"></script>
  <script src="assets/dashboard_assets/assets/js/todolist.js"></script>
  <!-- End custom js for this page -->
</body>

</html>